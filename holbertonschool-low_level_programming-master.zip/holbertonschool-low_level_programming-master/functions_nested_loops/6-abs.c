#include "main.h"

/**
 *_abs- gets users input
 *@c: stores the users input in this variable
 *Return: returns the answer
 */


int _abs(int c)
{
	if (c < 0)
		return (-c);

	else
		return (c);

}
