in this project wll be working with nested loops 

