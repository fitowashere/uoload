#include "main.h"

/**
 * add- gets users input
 * @a: gets first input
 * @b: gets second input
 * Return: returns result
 */

int add(int a, int b)
{

int c = a + b;

return (c);

}
