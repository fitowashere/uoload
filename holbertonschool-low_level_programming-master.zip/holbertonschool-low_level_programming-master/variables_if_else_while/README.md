in this project wll be working with if else while and for loops 

