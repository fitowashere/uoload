#include<stdio.h>

/**
 * main- inicialized the program makes a list of character to make the alphabet
 * Return: 0
 */

int main(void)
{
	char ch;

	for (ch = 'a'; ch <= 'z'; ch++)
	{
		if ((ch != 'e') && (ch != 'q'))
		{
			putchar(ch);

		}
	}
	putchar('\n');
	return (0);
}
