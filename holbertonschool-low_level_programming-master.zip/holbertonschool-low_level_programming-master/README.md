in this Repository we will learn C.
